package com.example.grantoseguros;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Cadastro(View view){
        Intent it = new Intent(this,MainActivityCadastro.class);
        startActivity(it);
    }
    public void Login(View view) {
        Intent it = new Intent(this, MainActivityOpContratos.class);
        startActivity(it);
    }
}