package com.example.grantoseguros;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivityMeusContratos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_meus_contratos);

        ListView lv1 = (ListView) findViewById(R.id.Lista1);
        String[] vetacoes = getResources().getStringArray(R.array.lista_de_acoes1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,vetacoes);
        lv1.setAdapter(adapter);

        ListView lv2 = (ListView) findViewById(R.id.Lista2
        );
        String[] vetacoes2 = getResources().getStringArray(R.array.lista_de_acoes2);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,vetacoes2);
        lv2.setAdapter(adapter1);

        ListView lv3 = (ListView) findViewById(R.id.Lista3);
        String[] vetacoes3 = getResources().getStringArray(R.array.lista_de_acoes3);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,vetacoes3);
        lv3.setAdapter(adapter2);
    }

}
