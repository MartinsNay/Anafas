package com.example.grantoseguros;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivityNewContatos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_new_contatos);
    }
    public void op(View view){
        Intent it = new Intent(this,MainActivityOpContratos.class);
        startActivity(it);
    }
}