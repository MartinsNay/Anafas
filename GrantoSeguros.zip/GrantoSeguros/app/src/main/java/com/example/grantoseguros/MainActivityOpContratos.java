package com.example.grantoseguros;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;

public class MainActivityOpContratos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_op_contratos);
    }
    public void NewContratos(View view){
        Intent it = new Intent(this,MainActivityNewContatos.class);
        startActivity(it);
    }
    public void MeusContratos(View view){
        Intent it = new Intent(this,MainActivityMeusContratos.class);
        startActivity(it);
    }
    public void Simulacao(View view){
        Intent it = new Intent(this,MainActivitySimulacao.class);
        startActivity(it);
    }
    public void whats(View view){
        WebView webview = new WebView(this);
        // aqui vai as configurações para cada webview
        // carregar o site externo
        webview.loadUrl("https://api.whatsapp.com/send?phone=3433168055");
        //Exibir uma webview substituindo o layout da activity
        setContentView(webview);
    }
}