package com.example.grantoseguros;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MainActivitySimulacao extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main_simulacao);
        WebView webview = new WebView(this);

        // aqui vai as configurações para cada webview
        // carregar o site externo
        webview.loadUrl("https://grantoseguros.com/");
        //Exibir uma webview substituindo o layout da activity
        setContentView(webview);
    }
}